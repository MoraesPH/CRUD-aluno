
package crud_cadastro_alunos;


public class CRUD_cadastro_alunos {

    
    public static void main(String[] args) {
        
    }
    
}
